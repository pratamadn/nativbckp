package com.dnp.nativbaru;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class NativeNew extends AppCompatActivity {

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_dashboard:
                    DashboardFragment dsb = new DashboardFragment();
                    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentTransaction.replace(R.id.content, dsb);
                    fragmentTransaction.commit();
                    return true;
                case R.id.navigation_notif:
                    NotifFragment nf = new NotifFragment();
                    FragmentTransaction fragmentDTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentDTransaction.replace(R.id.content, nf);
                    fragmentDTransaction.commit();
                    return true;
                case R.id.navigation_home:
                    HomeFragment hm = new HomeFragment();
                    FragmentTransaction fragmentNTransaction = getSupportFragmentManager().beginTransaction();
                    fragmentNTransaction.replace(R.id. content, hm);
                    fragmentNTransaction.commit();
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_native_new);

        DashboardFragment dsb = new DashboardFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.content, dsb);
        fragmentTransaction.commit();
        BottomNavigationView navView = findViewById(R.id.nav_view);
//        mTextMessage = findViewById(R.id.message);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

}
